package upgrad.movieapp.service.movie.model;

public enum BookingStatus {

    CONFIRMED,CANCELLED;

}
