package upgrad.movieapp.service.movie.model;

public enum MovieSortBy {

    RATING, RELEASE_DATE;

}
