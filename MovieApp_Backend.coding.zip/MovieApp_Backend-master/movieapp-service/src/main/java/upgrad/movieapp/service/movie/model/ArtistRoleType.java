package upgrad.movieapp.service.movie.model;

public enum ArtistRoleType {

    DIRECTOR, PRODUCER, ACTOR, CINEMATOGRAPHER, MUSICIAN, STUNTMAN;

}
