/*
 * Copyright 2018-2019, https://beingtechie.io.
 *
 * File: ErrorCode.java
 * Date: May 5, 2018
 * Author: Thribhuvan Krishnamurthy
 */
package upgrad.movieapp.service.common.exception;

/**
 * TODO: Provide javadoc
 */
public interface ErrorCode {

    String getCode();

    String getDefaultMessage();

}